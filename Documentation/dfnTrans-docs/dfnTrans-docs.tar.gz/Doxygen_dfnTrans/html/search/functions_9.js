var searchData=
[
  ['openfile',['OpenFile',['../_func_def_8h.html#a205add90a27292ac5f18188fa35bcdf5',1,'OpenFile(char filen[120], char fileopt[2]):&#160;ReadGridInit.c'],['../_read_grid_init_8c.html#a205add90a27292ac5f18188fa35bcdf5',1,'OpenFile(char filen[120], char fileopt[2]):&#160;ReadGridInit.c']]],
  ['outputmarplumdisp',['OutputMarPlumDisp',['../_func_def_8h.html#a5d25bfed6640fd5e87e0e1f917e25218',1,'OutputMarPlumDisp(int currentnum, char path[125]):&#160;output.c'],['../output_8c.html#a5d25bfed6640fd5e87e0e1f917e25218',1,'OutputMarPlumDisp(int currentnum, char path[125]):&#160;output.c']]],
  ['outputvelocities',['OutputVelocities',['../_func_def_8h.html#ae95808a34380ac01e823c78d8a708eb3',1,'OutputVelocities():&#160;VelocityReconstruction.c'],['../_velocity_reconstruction_8c.html#ae95808a34380ac01e823c78d8a708eb3',1,'OutputVelocities():&#160;VelocityReconstruction.c']]]
];
