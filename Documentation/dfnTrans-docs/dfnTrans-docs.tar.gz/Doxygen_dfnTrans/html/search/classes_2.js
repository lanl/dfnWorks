var searchData=
[
  ['inpfile',['inpfile',['../structinpfile.html',1,'']]],
  ['intcoef',['intcoef',['../structintcoef.html',1,'']]]
];
