var searchData=
[
  ['darcyvelocity',['DarcyVelocity',['../_func_def_8h.html#a6c0b7207a055a56ec2091b578dcab307',1,'DarcyVelocity():&#160;VelocityReconstruction.c'],['../_velocity_reconstruction_8c.html#a6c0b7207a055a56ec2091b578dcab307',1,'DarcyVelocity():&#160;VelocityReconstruction.c']]],
  ['defineangle',['DefineAngle',['../_func_def_8h.html#a3759fb98594fea9a5c180b9d2324e027',1,'DefineAngle(double u1, double u2, double v1, double v2):&#160;VelocityReconstruction.c'],['../_velocity_reconstruction_8c.html#a3759fb98594fea9a5c180b9d2324e027',1,'DefineAngle(double u1, double u2, double v1, double v2):&#160;VelocityReconstruction.c']]],
  ['defineboundaryangle',['DefineBoundaryAngle',['../_func_def_8h.html#acc3803bef1f2fcc10f4f2a0ecc627b34',1,'DefineBoundaryAngle(int i, unsigned int edge_1, unsigned int edge_2, int f1, int coorf):&#160;VelocityReconstruction.c'],['../_velocity_reconstruction_8c.html#acc3803bef1f2fcc10f4f2a0ecc627b34',1,'DefineBoundaryAngle(int i, unsigned int edge_1, unsigned int edge_2, int f1, int coorf):&#160;VelocityReconstruction.c']]],
  ['definetimestep',['DefineTimeStep',['../_func_def_8h.html#ae1803816ac80e7c427387495c19a41c8',1,'DefineTimeStep():&#160;TrackingPart.c'],['../_tracking_part_8c.html#ae1803816ac80e7c427387495c19a41c8',1,'DefineTimeStep():&#160;TrackingPart.c']]]
];
