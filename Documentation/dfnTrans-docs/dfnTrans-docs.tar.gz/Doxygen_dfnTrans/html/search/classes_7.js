var searchData=
[
  ['vertex',['vertex',['../structvertex.html',1,'']]]
];
