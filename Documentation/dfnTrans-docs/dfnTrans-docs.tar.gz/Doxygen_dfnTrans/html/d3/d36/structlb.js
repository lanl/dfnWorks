var structlb =
[
    [ "angle", "d3/d36/structlb.html#a284a6ff364b4f64628f7a02f24251cb1", null ],
    [ "length_b", "d3/d36/structlb.html#a7f4b1a6c1c8446cde504704489e9a75f", null ],
    [ "norm", "d3/d36/structlb.html#a661e852334d1c5f1c8552b1eb2f06db8", null ]
];