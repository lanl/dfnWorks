var structintcoef =
[
    [ "weights", "d3/d1b/structintcoef.html#ab3d267bf2bc81e221bed2ebc1779dbf0", null ]
];