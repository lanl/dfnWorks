var structinpfile =
[
    [ "filename", "structinpfile.html#a66e8759aa38ee20350f04cdc58dee702", null ],
    [ "flag", "structinpfile.html#a23ae60bf94767194de9a09a4eee8cc1d", null ],
    [ "param", "structinpfile.html#a57ff2cce78c35a8a128927da9eeccfbc", null ]
];