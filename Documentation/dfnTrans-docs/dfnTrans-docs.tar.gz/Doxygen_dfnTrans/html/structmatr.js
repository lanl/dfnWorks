var structmatr =
[
    [ "matinv", "structmatr.html#a70ef628f861867c49550cad75d4c5b00", null ],
    [ "matrinvG", "structmatr.html#a2233efa6510134d01a3a0a0245f5d631", null ]
];