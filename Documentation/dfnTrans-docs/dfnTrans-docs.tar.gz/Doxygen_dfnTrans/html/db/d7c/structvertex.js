var structvertex =
[
    [ "aperture", "db/d7c/structvertex.html#a7588fad77cf759d8db0957c9e957e23a", null ],
    [ "area", "db/d7c/structvertex.html#aff6495cfbefb8dffd8714d7c68810ca6", null ],
    [ "cells", "db/d7c/structvertex.html#a583032cadaa99e8f5c044d3bd10191cf", null ],
    [ "coord", "db/d7c/structvertex.html#a1eff0deab63f96c97ba5098608d65ad3", null ],
    [ "coord_xy", "db/d7c/structvertex.html#a3473aebf2ce957df8c02095cc98ebb39", null ],
    [ "flux", "db/d7c/structvertex.html#a9934ed428ad1db71c9aa1e601649791c", null ],
    [ "fracts", "db/d7c/structvertex.html#adc1951216db706914f5963da2e58accc", null ],
    [ "fracture", "db/d7c/structvertex.html#aa2cd06573422bc415cb8f38a67232de7", null ],
    [ "indnodes", "db/d7c/structvertex.html#a82e41673a29352ee0f004ae7890d5266", null ],
    [ "numneighb", "db/d7c/structvertex.html#acf83b561551952403148f73fe032f57b", null ],
    [ "pressure", "db/d7c/structvertex.html#a54ac97be271319fa385aef0685ea0641", null ],
    [ "pvolume", "db/d7c/structvertex.html#a7cf1594124712ff00a9e4d00926f1010", null ],
    [ "residtime", "db/d7c/structvertex.html#a6ee9434e764f4105136cb10a8c5be642", null ],
    [ "timestep", "db/d7c/structvertex.html#a5e4c0ee67478edf757b52b50859dd25e", null ],
    [ "type", "db/d7c/structvertex.html#aeabf5788639be2723927c854aa11cd33", null ],
    [ "typeN", "db/d7c/structvertex.html#aa8c5c50393696a507d20dda8ec69fd51", null ],
    [ "velocity", "db/d7c/structvertex.html#a92493253fc12b459eb0599ec07c56743", null ]
];