var structmaterial =
[
    [ "firstcell", "structmaterial.html#a528c4eed064175c3377dde7380d17ddc", null ],
    [ "firstnode", "structmaterial.html#a82946cb78555ad8c4c14a12fbd7aa3f8", null ],
    [ "lastnode", "structmaterial.html#a9bbfaca53483df79578f4ae037867851", null ],
    [ "numbcells", "structmaterial.html#a84365556a52eb9959d6d869dda76433c", null ],
    [ "nvect_xy", "structmaterial.html#a64fad3469b934d7e29be84f2d9b7d7a3", null ],
    [ "nvect_z", "structmaterial.html#aa0a097a3f8fe23d9b3bd41d80cbfacfd", null ],
    [ "rot2mat", "structmaterial.html#a572b56f5488c560ee0fe118592b660a7", null ],
    [ "rot3mat", "structmaterial.html#a8df25744238b2b814530d49ad58f484d", null ],
    [ "theta", "structmaterial.html#add2db22d2a9dd5c1c2ec6f14038d43f6", null ]
];