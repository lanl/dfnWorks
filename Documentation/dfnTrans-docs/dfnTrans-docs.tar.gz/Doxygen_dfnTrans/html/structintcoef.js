var structintcoef =
[
    [ "weights", "structintcoef.html#ab3d267bf2bc81e221bed2ebc1779dbf0", null ]
];