var structlagrangian =
[
    [ "betta", "d8/d06/structlagrangian.html#ad5fabc5bfeccc6ba7e60fbdf966c21d7", null ],
    [ "initx", "d8/d06/structlagrangian.html#aa3a20ad03006649a17790bd31560af8f", null ],
    [ "inity", "d8/d06/structlagrangian.html#a75fb1c376f05bb7ba3eaee13cab24067", null ],
    [ "initz", "d8/d06/structlagrangian.html#a44e890e0ddb81f46f4aa3c1e7c029a73", null ],
    [ "tau", "d8/d06/structlagrangian.html#a6c0717ffd474442f1651a1f7ebec625f", null ]
];