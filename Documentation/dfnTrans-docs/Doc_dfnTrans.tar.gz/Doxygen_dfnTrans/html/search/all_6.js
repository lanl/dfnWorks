var searchData=
[
  ['halfpolygonvelocity',['HalfPolygonVelocity',['../d0/d75/_func_def_8h.html#a0210252e558723368a0288b57b6136ea',1,'HalfPolygonVelocity(int i, int k, int fractn, int indc, unsigned int fractj[max_neighb]):&#160;VelocityReconstruction.c'],['../d2/d79/_velocity_reconstruction_8c.html#a0210252e558723368a0288b57b6136ea',1,'HalfPolygonVelocity(int i, int k, int fractn, int indc, unsigned int fractj[max_neighb]):&#160;VelocityReconstruction.c']]]
];
