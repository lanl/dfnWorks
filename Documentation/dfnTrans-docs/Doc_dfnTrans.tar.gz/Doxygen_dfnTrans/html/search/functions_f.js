var searchData=
[
  ['writinginit',['WritingInit',['../d0/d75/_func_def_8h.html#aee37300c235f6fed3eea46ac342e7be6',1,'WritingInit():&#160;ReadGridInit.c'],['../d8/d0d/_read_grid_init_8c.html#aee37300c235f6fed3eea46ac342e7be6',1,'WritingInit():&#160;ReadGridInit.c']]]
];
