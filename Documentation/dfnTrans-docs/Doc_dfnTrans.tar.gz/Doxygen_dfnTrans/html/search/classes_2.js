var searchData=
[
  ['inpfile',['inpfile',['../d9/d26/structinpfile.html',1,'']]],
  ['intcoef',['intcoef',['../d3/d1b/structintcoef.html',1,'']]]
];
