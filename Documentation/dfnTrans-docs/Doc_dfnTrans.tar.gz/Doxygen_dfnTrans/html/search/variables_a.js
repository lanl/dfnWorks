var searchData=
[
  ['residtime',['residtime',['../db/d7c/structvertex.html#a6ee9434e764f4105136cb10a8c5be642',1,'vertex']]],
  ['rot2mat',['rot2mat',['../da/d20/structmaterial.html#a572b56f5488c560ee0fe118592b660a7',1,'material']]],
  ['rot3mat',['rot3mat',['../da/d20/structmaterial.html#a8df25744238b2b814530d49ad58f484d',1,'material']]]
];
